from urllib.parse import urlencode, parse_qsl
import sys, xbmcgui, xbmcplugin, requests
import xbmcaddon, xbmc, urllib.request

def check_for_update():
    addon = xbmcaddon.Addon()
    update_url = addon.getSetting("https://hoaivnpt.duckdns.org/addon_kodi/plugin.video.90phuttv.xml")
    try:
        with urllib.request.urlopen(update_url) as response:
            xml_data = response.read()
            # Parse XML data and compare versions
            # If newer version available, prompt user to update
    except Exception as e:
        xbmc.log(f"Error checking for update: {e}")
# Call check_for_update function when add-on starts
check_for_update()

base_url = sys.argv[0]
HANDLE = int(sys.argv[1])

def get_url(**kwargs):
    return base_url + '?' + urlencode(kwargs)

def list_genres(link, isfolder):
    respjs = requests.get(link, timeout=15).json()
    for k in respjs:
        name = k["name"]
        match = k["url"]
        logo = k["logo"]
        fanart = k["fanart"]
        desc = k["desc"]
        isfolder = k["isfolder"]
        list_item = xbmcgui.ListItem(name)
        list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
        list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
        if isfolder == "True":
            list_item.setProperty("IsPlayable", 'false')
            url = get_url(action='list_link', link=match)
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
        else:
            list_item.setProperty("IsPlayable", 'true')
            xbmcplugin.addDirectoryItem(HANDLE, match, list_item, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def router(string):
    params = dict(parse_qsl(string))
    if not params:
        list_genres('https://www.dropbox.com/scl/fi/pntssitspmuz8p1bz4a7j/90phuttv_addon.txt?rlkey=nmvti4si5j01p60ycfvj2k4cv&dl=1', True)
    elif params['action'] == 'list_link':
        list_genres(params['link'], True)
    else:
        raise ValueError(f'Invalid paramstring: {string}!')

if __name__ == '__main__':
    router(sys.argv[2][1:])